<?php 
	// $CAT = 'All';
// if (isset($_GET['cat']))
	// $CAT = $_GET['cat'];
// global $post;
// $PAGE_ID = $post -> ID;
// $url = get_bloginfo('url')."?page_id=$PAGE_ID";

echo "hello from php";
echo "hello from php";
echo "hello from php";
echo "hello from php";
echo "hello from php";
echo "hello from php";
?>
