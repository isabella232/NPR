<?php
add_theme_support( 'post-thumbnails' );
add_image_size( 'homepage-thumb', 220, 180, true );
?>