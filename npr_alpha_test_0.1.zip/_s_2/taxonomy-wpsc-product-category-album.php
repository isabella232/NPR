<?php
$path = get_bloginfo("template_directory")."/music.php";
echo $path;
include $path;
?>